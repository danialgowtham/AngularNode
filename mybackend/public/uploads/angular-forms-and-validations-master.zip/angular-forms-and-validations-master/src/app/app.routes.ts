import { Routes } from '@angular/router';
import { FormComponent } from './form-component/form.component';

export const rootRouterConfig: Routes = [
  { path: '', component: FormComponent }
];
