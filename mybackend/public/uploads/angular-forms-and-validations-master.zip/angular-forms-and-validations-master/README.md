# Angular Forms and Validations

This project is part of an Angular tutorial about forms and validations. 

Get the step by step free tutorial in https://angular-templates.io/tutorials/about/angular-forms-and-validations

Please support this project by simply putting a Github star ⭐. Share this library with friends on Twitter and everywhere else you can. 🙏. Thanks


## Installation
Run `npm install` to install all the required dependencies

Then run `ng serve` to start a dev server. Navigate to http://localhost:4200/. The app will automatically reload if you change any of the source files.

![](https://s3-us-west-2.amazonaws.com/angular-templates/tutorials/angular-forms-and-validations/angular-forms-and-validations-3.png)
